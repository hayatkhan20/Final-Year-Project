const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Variable to store the received data
let receivedData = null;

// Route to handle incoming sensor data
app.post('/data', (req, res) => {
    console.log('Received data:', req.body);
    // Insert data into database here

    // Store the received data
    receivedData = req.body;

    // Send response indicating data received successfully
    res.send('Data received successfully');
});

// Route handler for the /data endpoint to display the received data
app.get('/data', (req, res) => {
    if (receivedData) {
        res.send(`Received data: ${JSON.stringify(receivedData)}`);
    } else {
        res.send('No data received yet');
    }
});

// Route handler for the root endpoint
app.get('/', (req, res) => {
    res.send('Welcome to my server!');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

